# API说明

所有接口位于 `/api`。除注册/登录外必须有有效的 HttpOnly 会话Cookie。所有写入必须有与 `APP_ORIGIN` 相同的 `Origin` 头，JSON请求总大小最多2MB。成功直接返回数据；错误为 `{error:string}`，使用400/401/403/404/409/413/429/500/502/503。后端不接受客户端owner或服务商地址。

| 方法   | 路径                        | 输入/行为                                                                                    |
| ------ | --------------------------- | -------------------------------------------------------------------------------------------- |
| POST   | /auth/register、/auth/login | `{email,password}`，注册普通用户，创建7天会话                                                |
| POST   | /auth/logout                | `{}`，注销当前会话                                                                           |
| GET    | /me                         | 账号、时区、AI配置状态、用量统计                                                             |
| PATCH  | /settings                   | `{timezone,reminders}`                                                                       |
| DELETE | /account                    | `{password}`，永久删除账号及所属数据                                                         |
| GET    | /entities?trash=1           | 当前账号全部实体，省略trash只返回活跃数据                                                    |
| POST   | /entities                   | `{kind,topic:null或编号,data}`，返回持久实体                                                 |
| GET    | /entities/:id               | 单个活跃实体，验证用户归属                                                                   |
| PATCH  | /entities/:id               | `{topic,data,version}`，完整校验与乐观锁                                                     |
| DELETE | /entities/:id               | `{version}`，软删除，保留关联历史                                                            |
| GET    | /entities/:id/impact        | 删除前关联引用影响                                                                           |
| POST   | /entities/:id/restore       | `{version}`，恢复前验证关联                                                                  |
| GET    | /entities/:id/history       | 该实体历史快照                                                                               |
| POST   | /entities/:id/undo          | `{version,targetVersion}`，恢复历史形成新版本                                                |
| POST   | /transform                  | `{ids,versions:{编号:版本},parts:字符串数组或null}`，拆分或合并                              |
| GET    | /operations                 | 当前账号拆分/合并操作记录                                                                    |
| POST   | /operations/:id             | `{}`，事务整体撤销，校验所有受影响版本                                                       |
| GET    | /search?q=文本              | 按内容、标题、标签、状态和主题名搜索                                                         |
| GET    | /export                     | JSON账号备份，schemaVersion=1，不含密码/密钥                                                 |
| GET    | /export?format=md           | 可读Markdown导出                                                                             |
| POST   | /import                     | JSON备份对象，严格引用、版本、大小校验，事务导入                                             |
| GET    | /analyses?topic=:id         | 当前主题分析、快照、建议、过期状态                                                           |
| POST   | /analyses                   | `{topic,ids:[],mode,answers?:string}`，模式为整理思路/检查推导/生成下一步                    |
| POST   | /suggestions/:id            | `{action:"accept"或"ignore",kind?:"question"或"task",data?:修改后业务字段,feedback?:string}` |
| POST   | /feedback                   | `{analysisId:string或null,rating:"有用"或"部分有用"或"无用",comment}`                        |
| GET    | /admin                      | 仅admin聚合事件、AI成功率/耗时/用量、错误类别                                                |

实体kind：topic、record、card、relation、question、task、event、evidence、validation、review。每种可用字段、枚举和多对多引用由 `lib/schema.ts` 统一定义，前端表单与后端校验使用同一规则。返回实体有稳定id、owner、kind、topic、version、contentVersion、deletedAt、createdAt、updatedAt和data。不能传未定义字段。

例如新建验证任务：

```json
{
  "kind": "task",
  "topic": null,
  "data": {
    "title": "访谈3名用户",
    "type": "验证任务",
    "status": "待开始",
    "action": "询问实际使用场景",
    "information": "愿意尝试的条件",
    "criterion": "记录明确意愿和原因"
  }
}
```

引用目标不仅要求编号存在，还验证账号、类型、必要的同主题限制和活跃状态。关系from为多个卡片编号、to为一个卡片编号，type为推导/支持/反对/前提依赖/分类归属，reason说明理由。外部来源链接仅保存，服务器不会抓取任意URL。

AI建议采纳幂等：若已有target，重复调用直接返回该项目；旧分析不能创建新内容。卡片、关系、任务等写入与建议target保存都在同一SQLite事务中。未配置AI时不会发送外部请求，返回503。并发分析、频率和额度由数据库计数，重启不能绕过。

### 用量展示补充

`GET /me` 的usage保留原calls/events/dailyLimit/monthlyLimit，新增todayUsed/monthUsed（按账号时区的自然日、自然月）及rollingDayUsed/rollingMonthUsed（最近24小时、30天）。原有后端额度规则未改变，界面分别显示日历用量和滚动额度。新增统计只读取当前账号的调用记录。

## 独立思考补充（2026.10.13）

- 原文record新增可选refs（明确关联的现有对象）和lastPosition（仍使用原kind）。数据库结构及schemaVersion=1不变，旧原文不要求补字段。
- `POST /thoughts/:id/items`：`{kind,data,version}`，id必须是当前账号的活跃独立原文；在同一事务中创建对象并加入原文refs，version为原文版本。冲突或无效引用时全部回滚，不留下孤立对象。kind不能为topic。
- `POST /suggestions/:id`额外接受可选recordId和recordVersion。原文必须在本次分析快照内且属于独立思考，确认后将采纳对象原子关联；卡片保持AI推断来源。连续采纳的新增关联不会使同一分析误过期，实际正文变化继续阻止采纳。
- `POST /analyses`的topic为null时必须有明确ids，不再允许默认分析全部未归类内容。前端使用独立原文明确关联的范围或用户选中范围；其他主题及无关记录不会自动加入。
- 编辑可以保留未变更的已删除旧引用，同时显示失效提示；新建或新增的引用仍必须活跃、归属正确、类型正确。回收站恢复仍遵循原有活跃引用校验。

## 锁定和响应处理修复（r2）

数据库忙锁或锁定返回JSON 503，并有Retry-After: 2；初始化异常也在请求错误边界内，内部SQL、文件路径和凭据不进入响应。正常注册与初始会话在同一事务内保存，同邮箱竞争返回可读400。前端空响应或非JSON响应显示可读失败提示，保留输入。登录页和设置均标记为思考空间 · 2026.10.13-r2。

默认DATABASE_BUSY_TIMEOUT_MS=5000，允许1至30000毫秒，非法值回退到5000。已有WAL与schemaVersion=1只读取初始化状态；新初始化迁移在事务内完成。正常部署建议单实例；有多个实例时每个进程持有自己的SQLite连接，忙锁等待有上限，持续占用仍需处理实际持锁进程，不会自动删除运行数据。


## 追问会话（r3增量）

所有接口延续登录、账号隔离、同来源保护、限速与JSON错误。数据库版本2新增表，不改entities模型。

- `POST /api/guidance`：`{content, token: UUID, organize: boolean}`，原文和会话原子保存；同一账号token重试返回已有原文，防重复记录。
- `POST /api/guidance/:root`：初始化或读取会话，root为已有主题或独立原文，不覆盖旧内容、不自动请求AI。
- `GET /api/guidance/:root`：读取当前追问、回答、候选、暂停草稿、AI快照及过期状态。
- `PATCH /api/guidance/:root`：带会话version的冲突保护；action为answer（questionId/text/status: answered|unknown|skipped）、editAnswer（answerId/text/status）、acknowledge（answerId）、direction（goal|concern|basis|unknown|next|judgment）、pause（draft）、basic、prepare或confirm（候选id/text/kind/cardType）。确认事务写入正式记录，重试不重复创建。
- `POST /api/guidance/:root/ai`：`{version, mode?: 整理思路|检查推导|生成下一步}`，沿用DeepSeek配置与calls额度；返回`{session,stale}`。生成期间输入变化只保留过期快照，不替换当前问题。未配置503，不创建模拟结果。
- `GET /api/guidance/:root/history`：会话旧版本，包括原回答和候选。编辑回答不改写已确认实体。

JSON备份仍支持schemaVersion=1。新导出额外包含guidance/guidanceHistory；旧备份没有这两项时按空处理。导入在同一事务中映射实体归属/目标，保留来源回答快照，并使历史AI分析过期。Markdown导出也包含问答记录。


## r4 目的追问与持续更新

`PATCH /guidance/:root` 在原命令基础上支持：

- `reframe`：`version, reason`（direct/abstract/missing/notApplicable），同轮九种策略不重复。保留问题身份、目的和引用，不创建回答。
- `scenario`：`version, scenario`（general/decision/project/reflection），可带draft；旧问题与草稿暂存。再次进入优先未处理前置事项。
- `focus`：`version, targetId` 或 `answerId`，围绕相关判断或信息缺口继续；可带draft。
- `resume`：`version, id`，恢复暂存问题；可带draft。
- `answer` / `edit`：可带 `assessment`。默认unspecified，不靠文本关键词猜测；明确选择clear/vague/inferred/observed/preference/decision/external/internal/misunderstood/notApplicable/unwilling影响基础分支。
- `ignoreCandidate`：`version, id`，放弃候选后不会在同源prepare时重新生成。

`POST /guidance/:root/updates`：所有动作必须包含`version`与UUID `token`。相同token相同内容幂等返回原结果；不同内容409。事务中同时检查会话和实体版本。

| action | 主要参数 | 结果 |
| --- | --- | --- |
| information | text或evidenceId、evidenceType、targets、stance(supports/opposes/related) | 新增/复用当前账号材料，显式关联判断，原文不变、原依据保留，建立待核对影响 |
| judgment | text、可选entityId/entityVersion、why/uncertain/conditions/method/evidenceRefs | 用户确认的新看法；少量更新保留省略字段；旧内容在实体历史及会话版本中保留 |
| result | taskId/taskVersion、targets、可选happened/information/influence/criterion | 完成行动并记录实际结果，产生未核实材料及待核对提示；不创建验证成功结论 |
| check | impactId、status(still/adjust/uncertain)、comment | 保存用户核对；仍适用不会改写判断；调整/不确定保留待处理状态 |

返回`{session,update}`。会话data增加agenda、parked、judgments、updates、impacts，旧JSON缺少字段时使用兼容默认值。`GET /guidance/:root` 增加requests：审计实际输入快照、版本、结果或可读错误，不含API密钥。服务端使用guidance_requests增量表，schema_migrations=3。

`POST /guidance/:root/ai` 可带`intent:next|reframe`与reason，沿用原供应商/模型/额度。实际请求先持久审计；输出校验相关回答、明确前置条件、同目的改写、范围内目标与非事实来源。返回期间版本变动只保留过期分析，不覆盖当前状态。成功与失败均保留输入快照；不会用基础模板冒充AI结果。

账号JSON导出的schemaVersion仍为1，新增可选guidanceRequests，并完整导出会话与历史。导入重映射显式实体引用、判断、更新、影响和输入快照，导入AI请求作为过期历史。Markdown包含新信息、行动结果和看法前后文字。

## r4.1 候选来源校验

AI输入快照新增candidateSources目录，列出允许引用的回答编号、状态、短摘录与用途。unknown只能用于问题、候选确认行动或问题卡片；skipped/review及其他范围的编号不可采纳。没有来源的候选也不可采纳。

候选的来源错误单独拦截，不影响有效下一问与其他有效候选。原始candidates仍留在runs[].result及guidance_requests.result审计，新增candidateWarnings数组（text、reason）；只有通过校验的项进入data.candidates。确认接口仍只接受data.candidates中实际存在、未过期的候选。没有可采纳候选也是合法分析结果，不代表用户已完成决定。无效问题本身与格式/事实误标保护仍返回可读错误。
